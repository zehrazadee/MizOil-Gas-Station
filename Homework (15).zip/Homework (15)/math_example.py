#Bu program riyazi əməliyyatı göstərir

import math

print("9 - un kvadrat kökü:", math.sqrt(9))
print("2 üstü 5:", math.pow(2, 5))
print("Pi sabiti:", math.pi)
print("5 faktorial:", math.factorial(5))